package JSPTest;

public class studentBean {
    public studentBean() {
    }
    private String name;
    private int rollno;
    private String state;
    private String country;
    public void setName(String name)
    {
       this.name=name;
     }
    public String getName()
    {
       return name;
     }
    public void setState(String state)
    {
       this.state=state;
     }
    public String getState()
    {
        return state;
    }
    public void setCountry(String country)
    {
       this.country=country;
     }
    public String getCountry()
    {
        return country;
    }
    public void setRollno(int rollno)
    {
       this.rollno=rollno;
     }
    public int getRollno()
    {
        return rollno;
    }
}
