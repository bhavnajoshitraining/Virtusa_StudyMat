package com.example.demo.dao;

import com.example.demo.model.Employee;

//@service is not added on interface , it is used on implementing class
public interface EmployeeDao {
	public abstract void createEmployee(Employee employee);
	
}

